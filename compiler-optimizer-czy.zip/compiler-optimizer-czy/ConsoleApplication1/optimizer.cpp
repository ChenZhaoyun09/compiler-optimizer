﻿#include <cstdio>
#include <cstring>
#include <unordered_map>
#include "analyser.h"
#include "Topo_relative.h"
using namespace std;

char reference_filename[] = "D:\\compiler_optimizer\\instruction(1).csv";
char input_file[] = "D:\\compiler_optimizer\\matmult\\Debug\\matmult.s";
char output_file[] = "D:\\compiler_optimizer\\matmult\\Debug\\matmult_pro.s";


int main()
{
    refer_table.load_table(reference_filename);
    load_func_table();
    process_file(output_file, input_file);
    return 0;
}

